<!DOCTYPE html>
<html>
<head>
<title>Doctor's Dashboard</title>
</head>
<body>
<?php
include("../include/header.html");

?>
</body>
</html>