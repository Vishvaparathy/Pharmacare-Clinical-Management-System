<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
<title>Doctor's Dashboard</title>
</head>
<body>
<?php
include("../include/header.html");
include("../include/connection.php");

?>

<div class="container-fluid">
    <div class="col-md-12">
	    <div class="row">
		    <div class="col-md-2">
			   <?php
			   
			   include("sidenav.php")
			   
			   ?>
			</div>
			<div class="col-md-10">
			    <div class="container-fluid">
				  <h5 class="text-white my-4"> Doctor's Dashboard</h5>
				    <div class="col-md-12">
					    <div class="row">
						    <div class="col-md-3 my-2 bg-info mx-2" style="height:150px;">
							<div class="col-md-12">
							    <div class="row">
								    <div class="col-md-8">
									    <h5 class="text-white my-4"> My Profile</h5>
									</div>
									<div class="col-md-4">
									   
									   <a href="profile.php"><img src="images.jpg" style="padding:16px; height:70px; width: 70px;" class="my-1" ></a>
									</div>
								</div>
							</div>
							</div>
							
							<div class="col-md-3 my-2 bg-warning mx-2" style="height:150px;">
							<div class="col-md-12">
							    <div class="row">
								    <div class="col-md-8">
									<?php
									$p = mysqli_query($connect, "SELECT*FROM patient");
								
								$pp=mysqli_num_rows($p);
								
								?>
									    <h5 class="text-white my-2" style="font-size: 30px;"> <?php echo $pp;   ?></h5>
										<h5 class="text-white my-4"> Total</h5>
										<h5 class="text-white my-4"> Patient</h5>
									</div>
									<div class="col-md-4">
									   
									   <a href="patient.php"><img src="medical.png" style="padding:10px; height:70px; width: 70px;" class="my-1" ></a>
									</div>
								</div>
							</div>
							</div>
							<div class="col-md-3 my-2 bg-success mx-2" style="height:150px;">
							<div class="col-md-12">
							    <div class="row">
								    <div class="col-md-8">
									<?php
									$app = mysqli_query($connect, "SELECT*FROM appointment WHERE status='Pending'");
								
								$appoint=mysqli_num_rows($app);
								
								?>
									    <h5 class="text-white my-2" style="font-size: 30px"><?php echo $appoint;   ?> </h5>
										<h5 class="text-white my-4"> Total</h5>
										<h5 class="text-white my-4"> Appointment</h5>
									</div>
									<div class="col-md-4">
									   
									   <a href="appointment.php"><img src="calendar.png" style="padding:16px; height:70px; width: 70px;" class="my-1" ></a>
									</div>
								</div>
							</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
</body>
</html>