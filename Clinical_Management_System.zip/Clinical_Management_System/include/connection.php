<?php
$connect = mysqli_connect("localhost", "root", "", "clms");

if (!$connect) {
    die("Connection failed: " . mysqli_connect_error());
}
?>