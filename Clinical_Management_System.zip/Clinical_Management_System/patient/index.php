<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
<title>Patient Dashboard</title>
</head>
<body>
<?php
include("../include/header.html");
include("../include/connection.php");

?>

<div class="container-fluid">
    <div class="col-md-12">
	    <div class="row">
		    <div class="col-md-2">
			   <?php
			   include("sidenav.php");
			   ?>
			</div>
			<div class="col-md-10">
			    <div class="container-fluid">
				  <h5 class="text-white my-3"> Patient Dashboard</h5>
				    <div class="col-md-12">
					    <div class="row">
						    <div class="col-md-3 my-2 bg-info mx-2" style="height:150px;">
							<div class="col-md-12">
							    <div class="row">
								    <div class="col-md-8">
									    <h5 class="text-white my-4"> My Profile</h5>
									</div>
									<div class="col-md-4">
									   <a href="profile.php"><img src="images.jpg" style="padding:16px; height:70px; width: 70px;" class="my-1"></a>
									</div>
								</div>
							</div>
							</div>
							
							<div class="col-md-3 my-2 bg-warning mx-2" style="height:150px;">
							<div class="col-md-12">
							    <div class="row">
								    <div class="col-md-8">
									    <h5 class="text-white my-4"> Book Appointment</h5>
									</div>
									<div class="col-md-4">
									   <a href="appointment.php"><img src="calendar.png" style="padding:16px; height:70px; width: 70px;" class="my-1"></a>
									</div>
								</div>
							</div>
							</div>
							
							<div class="col-md-3 my-2 bg-success mx-2" style="height:150px;">
							<div class="col-md-12">
							    <div class="row">
								    <div class="col-md-8">
									    <h5 class="text-white my-4"> My Invoice</h5>
									</div>
									<div class="col-md-4">
									   <a href="invoice.php"><img src="money.png" style="padding:16px; height:70px; width: 70px;" class="my-1"></a>
									</div>
								</div>
							</div>
							</div>
						</div>
					</div>
					
					<?php
					if(isset($_POST['Send'])) {
						$title = $_POST['title'];
						$message = $_POST['message'];
						
						if(empty($title)) {
							echo "<script> alert('Please enter a title for the report');</script>";
						} elseif(empty($message)) {
							echo "<script> alert('Please enter a message for the report');</script>";
						} else {
							$user = $_SESSION['patient'];
							
							$query = "INSERT INTO report (title, message, username, date_send) VALUES ('$title', '$message', '$user', NOW())";
							$res = mysqli_query($connect, $query);
							
							if($res) {
								echo "<script> alert('You have sent your Report');</script>";
							} else {
								echo "<script> alert('Error sending report');</script>";
							}
						}
					}
					?>

					<div class="col-md-12">
					 <div class="row">
					     <div class="col-md-3"></div>
						 
						 <div class="col-md-6 jumbotron bg-info my-5"> 
						 <h5 class="text-center my-2">Send A Report</h5>
						 <form method="post">
						   <label>Title</label>
						   <input type="text" name="title" autocomplete="off" class="form-control" placeholder="Enter Title of the report">
						   
						   <label>Message</label>
						   <input type="text" name="message" autocomplete="off" class="form-control" placeholder="Enter message">
						   
						   <input type="submit" name="Send" value="Send Report" class="btn btn-success my-2">
						 </form>
						 </div>
						 <div class="col-md-3"></div>
					 </div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
</body>
</html>
